﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    bool isOnGround;

    float gravityModifier = 2.0f;

    Rigidbody playerRb;
    Renderer playerRdr;

    float jumpForce = 10.0f;
    float moveForce = 10.0f;
    float boundaryLimit = 5.0f;

    public Material[] playerMtrs;

    // Start is called before the first frame update
    void Start()
    {
        isOnGround = true;
        Physics.gravity *= gravityModifier;

        playerRb = GetComponent<Rigidbody>();
        playerRdr = GetComponent<Renderer>();
    }

    // Update is called once per frame
    void Update()
    {
        PlayerMove();
        PlayerJump();
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("GamePlane"))
        {
            isOnGround = true;
            playerRdr.material.color = playerMtrs[0].color;
        }
    }
    private void PlayerJump()
    {
        if (Input.GetKeyDown(KeyCode.Space) && isOnGround)
        {
            playerRb.AddForce(Vector3.up * jumpForce, ForceMode.Impulse);
            isOnGround = false;

            playerRdr.material.color = playerMtrs[1].color;
        }
    }
    private void PlayerMove()
    {
        float inputVertical = Input.GetAxis("Vertical");
        float inputHorizontal = Input.GetAxis("Horizontal");

        if(transform.position.z < -boundaryLimit)
        {
            transform.position = new Vector3(transform.position.x, transform.position.y, -boundaryLimit);
            playerRdr.material.color = playerMtrs[2].color;
        }
        else if(transform.position.z > boundaryLimit)
        {
            transform.position = new Vector3(transform.position.x, transform.position.y, boundaryLimit);
            playerRdr.material.color = playerMtrs[2].color;
        }
        else
        {
            transform.Translate(Vector3.forward * inputVertical * moveForce * Time.deltaTime);
            if (Input.GetKeyDown(KeyCode.UpArrow) || Input.GetKeyDown(KeyCode.DownArrow) || Input.GetKeyDown(KeyCode.W) || Input.GetKeyDown(KeyCode.S))
            {
                playerRdr.material.color = playerMtrs[4].color;
            }
        }

        if (transform.position.x < -boundaryLimit)
        {
            transform.position = new Vector3(-boundaryLimit, transform.position.y, transform.position.z);
            playerRdr.material.color = playerMtrs[3].color;
        }
        else if (transform.position.x > boundaryLimit)
        {
            transform.position = new Vector3(boundaryLimit, transform.position.y, transform.position.z);
            playerRdr.material.color = playerMtrs[3].color;
        }
        else
        {
            transform.Translate(Vector3.right * inputHorizontal * moveForce * Time.deltaTime);
            if (Input.GetKeyDown(KeyCode.RightArrow) || Input.GetKeyDown(KeyCode.LeftArrow) || Input.GetKeyDown(KeyCode.A) || Input.GetKeyDown(KeyCode.D))
            {
                playerRdr.material.color = playerMtrs[5].color;
            }
        }
    }
}
